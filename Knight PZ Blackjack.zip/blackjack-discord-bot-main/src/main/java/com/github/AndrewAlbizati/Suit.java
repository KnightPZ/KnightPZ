package com.github.AndrewAlbizati;

/**
 * Represents the different playing card suits.
 */
public enum Suit {
    SPADE, HEART, DIAMOND, CLUB
}
